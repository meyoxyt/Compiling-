import { useState, useEffect } from 'react';
import Header from '../components/Layout/Header';
import { siteService } from '../services/api';

export default function Sites() {
  const [sites, setSites] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({ domain: '', port: 80, php_version: '' });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    fetchSites();
  }, []);

  const fetchSites = async () => {
    try {
      const response = await siteService.list();
      setSites(response.data);
    } catch (error) {
      console.error('Failed to fetch sites:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateSite = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setSubmitting(true);

    try {
      await siteService.create(formData);
      setSuccess('Site created successfully!');
      setShowModal(false);
      setFormData({ domain: '', port: 80, php_version: '' });
      fetchSites();
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to create site');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteSite = async (domain) => {
    if (!confirm(`Are you sure you want to delete ${domain}? This cannot be undone.`)) {
      return;
    }

    try {
      await siteService.delete(domain);
      setSuccess('Site deleted successfully!');
      fetchSites();
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to delete site');
    }
  };

  const handleToggleStatus = async (site) => {
    const newStatus = site.status === 'active' ? 'disabled' : 'active';

    try {
      await siteService.toggleStatus(site.domain, newStatus);
      setSuccess(`Site ${newStatus === 'active' ? 'enabled' : 'disabled'} successfully!`);
      fetchSites();
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to update site status');
    }
  };

  return (
    <>
      <Header title="Sites" subtitle="Manage your hosted websites" />

      <div className="flex-1" style={{ padding: '32px', overflow: 'auto' }}>
        {/* Success/Error Messages */}
        {success && (
          <div className="alert alert-success mb-6">
            {success}
          </div>
        )}
        {error && (
          <div className="alert alert-error mb-6">
            {error}
          </div>
        )}

        {/* Add Site Button */}
        <div className="mb-6">
          <button
            onClick={() => setShowModal(true)}
            className="btn btn-primary"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 5v14M5 12h14" />
            </svg>
            Add New Site
          </button>
        </div>

        {/* Sites Grid */}
        {loading ? (
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '48px' }}>
            <div className="spinner"></div>
          </div>
        ) : sites.length === 0 ? (
          <div className="card" style={{ padding: '48px', textAlign: 'center' }}>
            <div style={{ width: '64px', height: '64px', margin: '0 auto 20px', color: '#d4d4d4' }}>
              <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10" />
                <path d="M2 12h20" />
                <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
              </svg>
            </div>
            <h3 className="text-lg font-semibold text-[#171717] mb-2">No sites configured</h3>
            <p className="text-[#737373] mb-6">Get started by adding your first website</p>
            <button onClick={() => setShowModal(true)} className="btn btn-primary">
              Add Your First Site
            </button>
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '24px' }}>
            {sites.map((site) => (
              <div key={site.id} className="card card-hover" style={{ padding: '24px' }}>
                <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '16px' }}>
                  <div>
                    <h3 className="text-lg font-semibold text-[#171717]">{site.domain}</h3>
                    <p className="text-sm text-[#737373]">Port: {site.port}</p>
                  </div>
                  <span className={`badge ${site.status === 'active' ? 'badge-active' : 'badge-inactive'}`}>
                    {site.status}
                  </span>
                </div>

                <div className="mb-4" style={{ fontSize: '13px', color: '#a3a3a3' }}>
                  <p>Document Root: <code>{site.document_root}</code></p>
                  <p style={{ marginTop: '4px' }}>Created: {new Date(site.created_at).toLocaleDateString()}</p>
                </div>

                <div style={{ display: 'flex', gap: '8px' }}>
                  <button
                    onClick={() => handleToggleStatus(site)}
                    className={`btn flex-1 ${site.status === 'active' ? 'btn-secondary' : 'btn-primary'}`}
                    style={{ fontSize: '13px', padding: '8px 12px' }}
                  >
                    {site.status === 'active' ? 'Disable' : 'Enable'}
                  </button>
                  <button
                    onClick={() => handleDeleteSite(site.domain)}
                    className="btn btn-ghost"
                    style={{ fontSize: '13px', padding: '8px 12px' }}
                  >
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M3 6h18" />
                      <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
                      <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
                    </svg>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add Site Modal */}
      {showModal && (
        <div className="modal-overlay">
          <div className="modal-content">
            <div className="modal-header">
              <h2 style={{ fontSize: '20px', fontWeight: '600', color: '#171717', fontFamily: 'DM Sans' }}>Add New Site</h2>
              <p style={{ fontSize: '14px', color: '#737373', marginTop: '4px', fontFamily: 'DM Sans' }}>Configure your new website</p>
            </div>

            <form onSubmit={handleCreateSite} className="modal-body">
              {error && (
                <div className="alert alert-error">
                  {error}
                </div>
              )}

              <div className="form-group">
                <label className="form-label">Domain Name</label>
                <input
                  type="text"
                  value={formData.domain}
                  onChange={(e) => setFormData({ ...formData, domain: e.target.value })}
                  className="input"
                  placeholder="example.com"
                  required
                />
                <p className="form-hint">Enter your domain without http:// or www.</p>
              </div>

              <div className="form-group">
                <label className="form-label">Port</label>
                <input
                  type="number"
                  value={formData.port}
                  onChange={(e) => setFormData({ ...formData, port: parseInt(e.target.value) })}
                  className="input"
                  placeholder="80"
                  required
                />
              </div>

              <div style={{ display: 'flex', gap: '12px', paddingTop: '16px' }}>
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="btn btn-secondary flex-1"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="btn btn-primary flex-1"
                >
                  {submitting ? (
                    <>
                      <div className="spinner"></div>
                      <span>Creating...</span>
                    </>
                  ) : (
                    'Create Site'
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
