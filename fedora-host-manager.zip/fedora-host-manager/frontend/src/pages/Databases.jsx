import { useState, useEffect } from 'react';
import Header from '../components/Layout/Header';
import { databaseService, siteService } from '../services/api';

export default function Databases() {
  const [databases, setDatabases] = useState([]);
  const [sites, setSites] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    domain: '',
    db_name: '',
    db_user: '',
    db_password: ''
  });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [connectionTest, setConnectionTest] = useState(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [databasesRes, sitesRes, connectionRes] = await Promise.all([
        databaseService.list(),
        siteService.list(),
        databaseService.testConnection()
      ]);

      setDatabases(databasesRes.data || []);
      setSites(sitesRes.data);
      setConnectionTest(connectionRes.data);
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateDatabase = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setSubmitting(true);

    try {
      await databaseService.create(formData);
      setSuccess('Database created successfully!');
      setShowModal(false);
      setFormData({ domain: '', db_name: '', db_user: '', db_password: '' });
      fetchData();
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to create database');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteDatabase = async (dbName) => {
    if (!confirm(`Are you sure you want to delete database "${dbName}"? This cannot be undone.`)) {
      return;
    }

    try {
      await databaseService.delete(dbName);
      setSuccess('Database deleted successfully!');
      fetchData();
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to delete database');
    }
  };

  return (
    <>
      <Header title="Databases" subtitle="Manage MySQL databases" />

      <div className="flex-1" style={{ padding: '32px', overflow: 'auto' }}>
        {/* Success/Error Messages */}
        {success && (
          <div className="alert alert-success mb-6">
            {success}
          </div>
        )}
        {error && (
          <div className="alert alert-error mb-6">
            {error}
          </div>
        )}

        {/* MySQL Connection Status */}
        <div className="card" style={{ padding: '24px', marginBottom: '24px' }}>
          <h2 className="section-title mb-4">MySQL Connection</h2>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={{ width: '10px', height: '10px', borderRadius: '50%', background: connectionTest?.connected ? '#171717' : '#d4d4d4' }}></div>
            <span className={connectionTest?.connected ? 'text-[#171717]' : 'text-[#737373]'}>
              {connectionTest?.connected ? 'Connected' : 'Not Connected'}
            </span>
          </div>
          {!connectionTest?.connected && (
            <p className="text-sm text-[#a3a3a3] mt-3">
              Make sure MariaDB/MySQL is installed and running on your system.
            </p>
          )}
        </div>

        {/* Create Database Button */}
        <div className="mb-6">
          <button
            onClick={() => setShowModal(true)}
            className="btn btn-primary"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 5v14M5 12h14" />
            </svg>
            Create Database
          </button>
        </div>

        {/* Databases List */}
        {loading ? (
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '48px' }}>
            <div className="spinner"></div>
          </div>
        ) : databases.length === 0 ? (
          <div className="card" style={{ padding: '48px', textAlign: 'center' }}>
            <div style={{ width: '64px', height: '64px', margin: '0 auto 20px', color: '#d4d4d4' }}>
              <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                <ellipse cx="12" cy="5" rx="9" ry="3" />
                <path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3" />
                <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5" />
              </svg>
            </div>
            <h3 className="text-lg font-semibold text-[#171717] mb-2">No databases created</h3>
            <p className="text-[#737373] mb-6">Create your first database for a website</p>
            <button onClick={() => setShowModal(true)} className="btn btn-primary">
              Create Database
            </button>
          </div>
        ) : (
          <div className="card" style={{ padding: '24px' }}>
            <div style={{ overflowX: 'auto' }}>
              <table className="table">
                <thead>
                  <tr>
                    <th>Database Name</th>
                    <th>Username</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {databases.map((db, index) => (
                    <tr key={index}>
                      <td>
                        <span className="font-medium text-[#171717]">{db}</span>
                      </td>
                      <td className="text-[#737373]">{db.replace(/_/g, '_')}</td>
                      <td>
                        <button
                          onClick={() => handleDeleteDatabase(db)}
                          className="icon-btn"
                        >
                          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M3 6h18" />
                            <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
                            <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
                          </svg>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Create Database Modal */}
      {showModal && (
        <div className="modal-overlay">
          <div className="modal-content">
            <div className="modal-header">
              <h2 style={{ fontSize: '20px', fontWeight: '600', color: '#171717', fontFamily: 'DM Sans' }}>Create Database</h2>
              <p style={{ fontSize: '14px', color: '#737373', marginTop: '4px', fontFamily: 'DM Sans' }}>Set up a new MySQL database</p>
            </div>

            <form onSubmit={handleCreateDatabase} className="modal-body">
              {error && (
                <div className="alert alert-error">
                  {error}
                </div>
              )}

              <div className="form-group">
                <label className="form-label">Associated Site</label>
                <select
                  value={formData.domain}
                  onChange={(e) => setFormData({ ...formData, domain: e.target.value })}
                  className="input"
                  required
                >
                  <option value="">Select a site</option>
                  {sites.map((site) => (
                    <option key={site.id} value={site.domain}>
                      {site.domain}
                    </option>
                  ))}
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Database Name</label>
                <input
                  type="text"
                  value={formData.db_name}
                  onChange={(e) => setFormData({ ...formData, db_name: e.target.value })}
                  className="input"
                  placeholder="mywebsite_db"
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label">Database User</label>
                <input
                  type="text"
                  value={formData.db_user}
                  onChange={(e) => setFormData({ ...formData, db_user: e.target.value })}
                  className="input"
                  placeholder="dbuser"
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label">Password (optional)</label>
                <input
                  type="password"
                  value={formData.db_password}
                  onChange={(e) => setFormData({ ...formData, db_password: e.target.value })}
                  className="input"
                  placeholder="Leave empty for auto-generated"
                />
                <p className="form-hint">If left empty, a random password will be generated</p>
              </div>

              <div style={{ display: 'flex', gap: '12px', paddingTop: '16px' }}>
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="btn btn-secondary flex-1"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="btn btn-primary flex-1"
                >
                  {submitting ? (
                    <>
                      <div className="spinner"></div>
                      <span>Creating...</span>
                    </>
                  ) : (
                    'Create Database'
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
