import { useState, useEffect } from 'react';
import Header from '../components/Layout/Header';
import { useAuth } from '../context/AuthContext';
import { systemService } from '../services/api';

export default function Settings() {
  const { user } = useAuth();
  const [serverInfo, setServerInfo] = useState(null);
  const [networkInfo, setNetworkInfo] = useState([]);
  const [loading, setLoading] = useState(true);
  const [reloading, setReloading] = useState(false);
  const [testing, setTesting] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });

  useEffect(() => {
    fetchInfo();
  }, []);

  const fetchInfo = async () => {
    try {
      const [infoRes, networkRes] = await Promise.all([
        systemService.getInfo(),
        systemService.getNetwork()
      ]);

      setServerInfo(infoRes.data);
      setNetworkInfo(networkRes.data);
    } catch (error) {
      console.error('Failed to fetch info:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleReloadNginx = async () => {
    setReloading(true);
    setMessage({ type: '', text: '' });

    try {
      const response = await systemService.reloadNginx();
      if (response.data.success) {
        setMessage({ type: 'success', text: 'Nginx reloaded successfully!' });
      } else {
        setMessage({ type: 'error', text: response.data.message || 'Failed to reload Nginx' });
      }
    } catch (error) {
      setMessage({ type: 'error', text: error.response?.data?.error || 'Failed to reload Nginx' });
    } finally {
      setReloading(false);
    }
  };

  const handleTestNginx = async () => {
    setTesting(true);
    setMessage({ type: '', text: '' });

    try {
      const response = await systemService.testNginx();
      if (response.data.success) {
        setMessage({ type: 'success', text: 'Nginx configuration is valid!' });
      } else {
        setMessage({ type: 'error', text: response.data.error || 'Invalid configuration' });
      }
    } catch (error) {
      setMessage({ type: 'error', text: error.response?.data?.error || 'Failed to test Nginx' });
    } finally {
      setTesting(false);
    }
  };

  if (loading) {
    return (
      <>
        <Header title="Settings" subtitle="Server configuration" />
        <div className="flex-1" style={{ padding: '32px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div className="spinner"></div>
        </div>
      </>
    );
  }

  return (
    <>
      <Header title="Settings" subtitle="Server configuration" />

      <div className="flex-1" style={{ padding: '32px', overflow: 'auto' }}>
        {/* Messages */}
        {message.text && (
          <div className={`alert mb-6 ${message.type === 'success' ? 'alert-success' : 'alert-error'}`}>
            {message.text}
          </div>
        )}

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: '24px' }}>
          {/* Server Information */}
          <div className="card" style={{ padding: '24px' }}>
            <h2 className="section-title mb-4">Server Information</h2>
            <div style={{ display: 'flex', flexDirection: 'column' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 0', borderBottom: '1px solid #f5f5f5' }}>
                <span className="text-[#737373]">Operating System</span>
                <span className="text-[#171717] font-medium">{serverInfo?.os}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 0', borderBottom: '1px solid #f5f5f5' }}>
                <span className="text-[#737373]">Hostname</span>
                <span className="text-[#171717] font-medium">{serverInfo?.hostname}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 0', borderBottom: '1px solid #f5f5f5' }}>
                <span className="text-[#737373]">Uptime</span>
                <span className="text-[#171717] font-medium">{serverInfo?.uptime}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 0', borderBottom: '1px solid #f5f5f5' }}>
                <span className="text-[#737373]">CPU Cores</span>
                <span className="text-[#171717] font-medium">{serverInfo?.cpu?.cores}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 0' }}>
                <span className="text-[#737373]">Memory</span>
                <span className="text-[#171717] font-medium">{serverInfo?.memory?.used} / {serverInfo?.memory?.total}</span>
              </div>
            </div>
          </div>

          {/* Network Information */}
          <div className="card" style={{ padding: '24px' }}>
            <h2 className="section-title mb-4">Network Interfaces</h2>
            {networkInfo.length === 0 ? (
              <p className="text-[#737373]">No network interfaces found</p>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {networkInfo.map((iface, index) => (
                  <div key={index} style={{ padding: '16px', background: '#fafafa', borderRadius: '8px' }}>
                    <p className="text-sm text-[#737373] mb-1">{iface.name}</p>
                    <p className="text-[#171717] font-mono" style={{ fontFamily: 'DM Sans' }}>{iface.ip}</p>
                    {iface.mac && <p className="text-xs text-[#a3a3a3] mt-1">MAC: {iface.mac}</p>}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Nginx Management */}
          <div className="card" style={{ padding: '24px' }}>
            <h2 className="section-title mb-4">Nginx Management</h2>
            <p className="text-[#737373] text-sm mb-4">Test and reload your Nginx configuration</p>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <button
                onClick={handleTestNginx}
                disabled={testing}
                className="btn btn-secondary"
              >
                {testing ? (
                  <>
                    <div className="spinner"></div>
                    <span>Testing...</span>
                  </>
                ) : (
                  <>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
                      <polyline points="22 4 12 14.01 9 11.01" />
                    </svg>
                    Test Configuration
                  </>
                )}
              </button>

              <button
                onClick={handleReloadNginx}
                disabled={reloading}
                className="btn btn-primary"
              >
                {reloading ? (
                  <>
                    <div className="spinner"></div>
                    <span>Reloading...</span>
                  </>
                ) : (
                  <>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M21.5 2v6h-6" />
                      <path d="M21.34 15.57a10 10 0 1 1-.57-8.38" />
                    </svg>
                    Reload Nginx
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Domain Linking Guide */}
          <div className="card" style={{ padding: '24px' }}>
            <h2 className="section-title mb-4">Link Your Domain</h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', fontSize: '14px', color: '#737373' }}>
              <div>
                <h3 className="font-medium text-[#171717] mb-2">1. Find your server IP</h3>
                <p>Your server IP address is: <code style={{ background: '#f5f5f5', padding: '2px 8px', borderRadius: '4px', color: '#171717' }}>{networkInfo[0]?.ip || 'Unknown'}</code></p>
              </div>

              <div>
                <h3 className="font-medium text-[#171717] mb-2">2. Update DNS Records</h3>
                <p>Add an A record in your domain's DNS settings pointing to your server IP.</p>
              </div>

              <div>
                <h3 className="font-medium text-[#171717] mb-2">3. Local Testing</h3>
                <p>Add this line to your <code>/etc/hosts</code> file:</p>
                <pre style={{ background: '#fafafa', padding: '12px', borderRadius: '8px', marginTop: '8px', overflow: 'auto' }}>
                  <code style={{ color: '#171717' }}>{networkInfo[0]?.ip || 'YOUR_IP'} yourdomain.com</code>
                </pre>
              </div>

              <div>
                <h3 className="font-medium text-[#171717] mb-2">4. Add Site in Dashboard</h3>
                <p>Go to Sites page and add your domain to start hosting.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
