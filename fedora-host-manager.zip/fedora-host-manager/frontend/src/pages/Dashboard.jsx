import { useState, useEffect } from 'react';
import Header from '../components/Layout/Header';
import { systemService, siteService } from '../services/api';

export default function Dashboard() {
  const [stats, setStats] = useState(null);
  const [sites, setSites] = useState([]);
  const [services, setServices] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const [statsRes, sitesRes, servicesRes] = await Promise.all([
        systemService.getStats(),
        siteService.list(),
        systemService.getServices()
      ]);

      setStats(statsRes.data);
      setSites(sitesRes.data);
      setServices(servicesRes.data);
    } catch (error) {
      console.error('Failed to fetch dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatUptime = (uptime) => {
    const parts = uptime.split(' ');
    if (parts.length >= 3) {
      return `${parts[0]}d ${parts[1]}h ${parts[2].replace('m', '')}m`;
    }
    return uptime;
  };

  if (loading) {
    return (
      <>
        <Header title="Dashboard" subtitle="Welcome back!" />
        <div className="flex-1" style={{ padding: '32px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div className="spinner"></div>
        </div>
      </>
    );
  }

  return (
    <>
      <Header title="Dashboard" subtitle="Welcome back!" />

      <div className="flex-1" style={{ padding: '32px', overflow: 'auto' }}>
        {/* Stats Grid */}
        <div className="stats-grid">
          {/* CPU */}
          <div className="card card-hover stats-card">
            <div className="stats-icon">
              <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#171717" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                <rect x="4" y="4" width="16" height="16" rx="2" />
                <rect x="9" y="9" width="6" height="6" />
                <path d="M9 1v3" />
                <path d="M15 1v3" />
                <path d="M9 20v3" />
                <path d="M15 20v3" />
                <path d="M20 9h3" />
                <path d="M20 14h3" />
                <path d="M1 9h3" />
                <path d="M1 14h3" />
              </svg>
            </div>
            <p className="stats-value">{stats?.cpu || 0}</p>
            <p className="stats-label">CPU Cores</p>
          </div>

          {/* Memory */}
          <div className="card card-hover stats-card">
            <div className="stats-icon">
              <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#171717" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                <rect x="2" y="6" width="20" height="12" rx="2" />
                <path d="M6 10h.01" />
                <path d="M10 10h.01" />
                <path d="M14 10h.01" />
                <path d="M18 10h.01" />
              </svg>
            </div>
            <p className="stats-value">{stats?.memory?.usedPercent || 0}%</p>
            <p className="stats-label">Memory Used</p>
            <p className="stats-extra">{stats?.memory?.used} / {stats?.memory?.total}</p>
          </div>

          {/* Sites */}
          <div className="card card-hover stats-card">
            <div className="stats-icon">
              <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#171717" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10" />
                <path d="M2 12h20" />
                <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
              </svg>
            </div>
            <p className="stats-value">{sites.filter(s => s.status === 'active').length}</p>
            <p className="stats-label">Active Sites</p>
          </div>

          {/* Uptime */}
          <div className="card card-hover stats-card">
            <div className="stats-icon">
              <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#171717" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10" />
                <polyline points="12 6 12 12 16 14" />
              </svg>
            </div>
            <p className="stats-value">{formatUptime(stats?.uptime || '0m')}</p>
            <p className="stats-label">Uptime</p>
          </div>
        </div>

        {/* Services Status */}
        <div className="card" style={{ padding: '24px', marginBottom: '32px' }}>
          <h2 className="section-title mb-4">Services Status</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: '16px' }}>
            {Object.entries(services).map(([name, status]) => (
              <div key={name} style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '16px', background: '#fafafa', borderRadius: '8px' }}>
                <div style={{ width: '10px', height: '10px', borderRadius: '50%', background: status.active ? '#171717' : '#d4d4d4' }}></div>
                <div>
                  <p className="text-sm font-medium text-[#171717]" style={{ textTransform: 'capitalize' }}>{name}</p>
                  <p className="text-xs text-[#a3a3a3]">{status.active ? 'Running' : 'Stopped'}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Sites */}
        <div className="card" style={{ padding: '24px' }}>
          <div className="section-header">
            <h2 className="section-title">Your Sites</h2>
          </div>
          {sites.length === 0 ? (
            <div className="empty-state">
              <div className="empty-state-icon">
                <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10" />
                  <path d="M2 12h20" />
                  <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
                </svg>
              </div>
              <p className="empty-state-title">No sites configured yet</p>
              <p className="empty-state-description">Add your first site to get started</p>
            </div>
          ) : (
            <div style={{ overflowX: 'auto' }}>
              <table className="table">
                <thead>
                  <tr>
                    <th>Domain</th>
                    <th>Port</th>
                    <th>Status</th>
                    <th>Created</th>
                  </tr>
                </thead>
                <tbody>
                  {sites.slice(0, 5).map((site) => (
                    <tr key={site.id}>
                      <td>
                        <span className="font-medium text-[#171717]">{site.domain}</span>
                      </td>
                      <td className="text-[#737373]">{site.port}</td>
                      <td>
                        <span className={`badge ${site.status === 'active' ? 'badge-active' : 'badge-inactive'}`}>
                          {site.status}
                        </span>
                      </td>
                      <td className="text-[#737373]">
                        {new Date(site.created_at).toLocaleDateString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
