import { useState, useEffect } from 'react';
import Header from '../components/Layout/Header';
import { siteService, fileService } from '../services/api';

export default function Files() {
  const [sites, setSites] = useState([]);
  const [selectedSite, setSelectedSite] = useState('');
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [diskUsage, setDiskUsage] = useState(null);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    fetchSites();
  }, []);

  useEffect(() => {
    if (selectedSite) {
      fetchFiles();
      fetchDiskUsage();
    }
  }, [selectedSite]);

  const fetchSites = async () => {
    try {
      const response = await siteService.list();
      setSites(response.data);
      if (response.data.length > 0) {
        setSelectedSite(response.data[0].domain);
      }
    } catch (error) {
      console.error('Failed to fetch sites:', error);
    }
  };

  const fetchFiles = async () => {
    if (!selectedSite) return;
    setLoading(true);
    try {
      const response = await fileService.list(selectedSite);
      setFiles(response.data);
    } catch (error) {
      console.error('Failed to fetch files:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchDiskUsage = async () => {
    try {
      const response = await fileService.getUsage();
      setDiskUsage(response.data);
    } catch (error) {
      console.error('Failed to fetch disk usage:', error);
    }
  };

  const handleFileUpload = async (e) => {
    const uploadedFiles = e.target.files;
    if (!uploadedFiles || uploadedFiles.length === 0) return;

    setUploading(true);
    try {
      await fileService.upload(selectedSite, Array.from(uploadedFiles));
      fetchFiles();
    } catch (error) {
      console.error('Failed to upload files:', error);
    } finally {
      setUploading(false);
    }
  };

  const handleDeleteFile = async (filePath) => {
    if (!confirm(`Delete ${filePath}?`)) return;

    try {
      await fileService.delete(selectedSite, filePath);
      fetchFiles();
    } catch (error) {
      console.error('Failed to delete file:', error);
    }
  };

  const formatSize = (size) => {
    if (!size) return '-';
    return size;
  };

  return (
    <>
      <Header title="File Manager" subtitle="Manage website files" />

      <div className="flex-1" style={{ padding: '32px', overflow: 'auto' }}>
        {/* Disk Usage */}
        {diskUsage && (
          <div className="card" style={{ padding: '24px', marginBottom: '24px' }}>
            <h2 className="section-title mb-4">Disk Usage</h2>
            <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
              <div style={{ flex: 1 }}>
                <div className="progress-bar">
                  <div className="progress-fill" style={{ width: `${diskUsage.percentUsed || 0}%` }}></div>
                </div>
              </div>
              <div className="text-sm text-[#737373]">
                {diskUsage.used} / {diskUsage.total} ({diskUsage.percentUsed}%)
              </div>
            </div>
          </div>
        )}

        {/* Site Selector and Upload */}
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '16px', marginBottom: '24px' }}>
          <div style={{ flex: 1, minWidth: '200px' }}>
            <label className="form-label">Select Site</label>
            <select
              value={selectedSite}
              onChange={(e) => setSelectedSite(e.target.value)}
              className="input"
            >
              {sites.map((site) => (
                <option key={site.id} value={site.domain}>
                  {site.domain}
                </option>
              ))}
            </select>
          </div>
          <div style={{ display: 'flex', alignItems: 'flex-end' }}>
            <label className="btn btn-primary" style={{ cursor: 'pointer' }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                <polyline points="17 8 12 3 7 8" />
                <line x1="12" y1="3" x2="12" y2="15" />
              </svg>
              {uploading ? 'Uploading...' : 'Upload Files'}
              <input
                type="file"
                multiple
                onChange={handleFileUpload}
                className="hidden"
                disabled={uploading}
              />
            </label>
          </div>
        </div>

        {/* File Browser */}
        <div className="card" style={{ padding: '24px' }}>
          <h2 className="section-title mb-4">
            Files: {selectedSite || 'No site selected'}
          </h2>

          {!selectedSite ? (
            <div style={{ textAlign: 'center', padding: '48px' }}>
              <p className="text-[#737373]">Please select a site to manage files</p>
            </div>
          ) : loading ? (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '48px' }}>
              <div className="spinner"></div>
            </div>
          ) : files.length === 0 ? (
            <div className="empty-state">
              <div className="empty-state-icon">
                <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
                  <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" />
                </svg>
              </div>
              <p className="empty-state-title">No files in this site</p>
              <p className="empty-state-description">Upload files to get started</p>
            </div>
          ) : (
            <div style={{ overflowX: 'auto' }}>
              <table className="table">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Path</th>
                    <th>Size</th>
                    <th>Modified</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {files.map((file, index) => (
                    <tr key={index}>
                      <td>
                        <div className="flex items-center gap-3">
                          {file.type === 'directory' ? (
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#171717" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                              <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
                            </svg>
                          ) : (
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#737373" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                              <polyline points="14 2 14 8 20 8" />
                              <line x1="16" y1="13" x2="8" y2="13" />
                              <line x1="16" y1="17" x2="8" y2="17" />
                            </svg>
                          )}
                          <span className="text-[#171717]">{file.name}</span>
                        </div>
                      </td>
                      <td className="text-[#737373] text-sm" style={{ fontFamily: 'DM Sans, monospace' }}>{file.path}</td>
                      <td className="text-[#737373]">{formatSize(file.size)}</td>
                      <td className="text-[#737373]">
                        {new Date(file.modified).toLocaleString()}
                      </td>
                      <td>
                        <button
                          onClick={() => handleDeleteFile(file.path)}
                          className="icon-btn"
                        >
                          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M3 6h18" />
                            <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
                            <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
                          </svg>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
