import { useAuth } from '../../context/AuthContext';

export default function Header({ title, subtitle }) {
  const { user, logout } = useAuth();

  return (
    <header style={{ background: '#ffffff', borderBottom: '1px solid #f5f5f5', padding: '24px 32px' }}>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-title">{title}</h1>
          {subtitle && <p className="page-subtitle">{subtitle}</p>}
        </div>

        <div className="flex items-center gap-4">
          {/* User menu */}
          <div className="flex items-center gap-3">
            <div className="avatar">
              {user?.username?.charAt(0).toUpperCase()}
            </div>
            <div style={{ display: 'none' }}>
              <p className="text-sm font-medium text-[#171717]">{user?.username}</p>
              <p className="text-xs text-[#a3a3a3]">{user?.role}</p>
            </div>
          </div>

          {/* Logout button */}
          <button
            onClick={logout}
            className="icon-btn"
            title="Logout"
            style={{ width: '40px', height: '40px' }}
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
              <polyline points="16 17 21 12 16 7" />
              <line x1="21" y1="12" x2="9" y2="12" />
            </svg>
          </button>
        </div>
      </div>
    </header>
  );
}
