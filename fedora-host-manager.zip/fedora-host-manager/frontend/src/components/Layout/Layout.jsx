import Sidebar from './Sidebar';

export default function Layout({ children }) {
  return (
    <div className="flex min-h-screen" style={{ background: '#fafafa' }}>
      <Sidebar />
      <main className="flex-1 flex flex-col overflow-hidden" style={{ minHeight: '100vh' }}>
        {children}
      </main>
    </div>
  );
}
