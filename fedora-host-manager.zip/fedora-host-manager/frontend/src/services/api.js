import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
  headers: {
    'Content-Type': 'application/json'
  }
});

// Request interceptor
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401 || error.response?.status === 403) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export default api;

// API service functions
export const siteService = {
  list: () => api.get('/sites'),
  get: (domain) => api.get(`/sites/${domain}`),
  create: (data) => api.post('/sites', data),
  update: (domain, data) => api.put(`/sites/${domain}`, data),
  delete: (domain) => api.delete(`/sites/${domain}`),
  toggleStatus: (domain, status) => api.put(`/sites/${domain}/status`, { status }),
  getConfig: (domain) => api.get(`/sites/${domain}/config`)
};

export const fileService = {
  list: (domain) => api.get(`/files/${domain}`),
  getContent: (domain, path) => api.get(`/files/${domain}/${path}`),
  create: (domain, data) => api.post(`/files/${domain}`, data),
  delete: (domain, path) => api.delete(`/files/${domain}/${path}`),
  upload: (domain, files) => {
    const formData = new FormData();
    files.forEach(file => formData.append('files', file));
    return api.post(`/files/${domain}/upload`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
  },
  getUsage: () => api.get('/files/usage')
};

export const databaseService = {
  list: () => api.get('/databases'),
  create: (data) => api.post('/databases', data),
  delete: (dbName) => api.delete(`/databases/${dbName}`),
  query: (dbName, query) => api.post(`/databases/${dbName}/query`, { query }),
  getSize: (dbName) => api.get(`/databases/${dbName}/size`),
  testConnection: () => api.get('/databases/test/connection')
};

export const systemService = {
  getStats: () => api.get('/system/stats'),
  getInfo: () => api.get('/system/info'),
  getNetwork: () => api.get('/system/network'),
  getServices: () => api.get('/system/services'),
  getLogs: (type) => api.get('/system/logs', { params: { type } }),
  reloadNginx: () => api.post('/system/nginx/reload'),
  testNginx: () => api.post('/system/nginx/test'),
  restartService: (service) => api.post('/system/services/restart', { service })
};
