# Fedora Host Manager

Turn your Fedora laptop into a powerful web hosting server with a beautiful web-based management dashboard.

## Features

- **Website Management**: Create, edit, and delete websites with automatic Nginx configuration
- **File Manager**: Upload, edit, and manage website files through the web interface
- **Database Management**: Create and manage MySQL/MariaDB databases for your websites
- **Domain Linking**: Configure custom domains and virtual hosts
- **Server Monitoring**: Monitor CPU, memory, disk usage, and service status
- **SSL Support**: Ready for SSL certificate configuration
- **Modern Dashboard**: Beautiful React-based web interface

## Quick Start

### Prerequisites

- Fedora Linux (Workstation or Server edition)
- Minimum 2GB RAM
- 10GB free disk space
- Internet connection

### Installation

1. **Clone or download this repository**

   ```bash
   cd /workspace
   git clone <repository-url> fedora-host-manager
   cd fedora-host-manager
   ```

2. **Run the setup script as root**

   ```bash
   sudo bash setup.sh
   ```

   The script will:
   - Update your system
   - Install Nginx, PHP-FPM, MariaDB, Node.js
   - Configure firewall
   - Set up the backend API
   - Build and configure the frontend
   - Create a sample website

3. **Access the dashboard**

   Open your browser and navigate to:
   - **Dashboard**: http://localhost:3000
   - **Sample Website**: http://sample.local

4. **Login with default credentials**

   - Username: `admin`
   - Password: `admin123`

   ⚠️ **Important**: Change the default password after first login!

## Project Structure

```
fedora-host-manager/
├── backend/                 # Node.js backend API
│   ├── src/
│   │   ├── controllers/    # Request handlers
│   │   ├── routes/         # API routes
│   │   ├── services/       # Business logic
│   │   ├── middleware/     # Auth middleware
│   │   └── utils/          # Utilities
│   └── nginx-templates/    # Nginx config templates
├── frontend/               # React frontend
│   ├── src/
│   │   ├── components/     # React components
│   │   ├── pages/          # Page components
│   │   ├── context/        # React context
│   │   └── services/       # API services
│   └── dist/               # Built files (after npm run build)
├── sample-website/         # Sample website files
├── server-config/          # Server configurations
└── setup.sh               # Automated setup script
```

## Managing Websites

### Adding a New Site

1. Navigate to **Sites** in the sidebar
2. Click **Add New Site**
3. Enter your domain name (e.g., `example.com`)
4. Click **Create Site**

The system will automatically:
- Create the document root directory
- Generate Nginx configuration
- Reload Nginx to apply changes

### Uploading Files

1. Navigate to **Files** in the sidebar
2. Select your site from the dropdown
3. Click **Upload Files** to upload your website content
4. Your files will be served immediately

### Linking Your Domain

#### Local Testing (Same Network)

Add your domain to the `/etc/hosts` file:

```bash
sudo bash -c 'echo "127.0.0.1 yourdomain.com" >> /etc/hosts'
```

#### Production (External Access)

1. **Find your server IP**

   ```bash
   hostname -I
   ```

2. **Configure your domain's DNS**

   Add an A record pointing to your server's IP address:

   ```
   Type: A
   Name: @ (or your subdomain)
   Value: YOUR_SERVER_IP
   TTL: 3600
   ```

3. **Port Forwarding (if behind a router)**

   Forward ports 80 (HTTP) and 443 (HTTPS) to your server.

4. **Add the site in dashboard**

   Navigate to Sites → Add New Site and enter your domain.

## API Documentation

The backend exposes a RESTful API:

### Authentication
- `POST /api/auth/login` - Login
- `POST /api/auth/register` - Register (if enabled)
- `GET /api/auth/profile` - Get user profile

### Sites
- `GET /api/sites` - List all sites
- `POST /api/sites` - Create new site
- `GET /api/sites/:domain` - Get site details
- `PUT /api/sites/:domain` - Update site
- `DELETE /api/sites/:domain` - Delete site
- `PUT /api/sites/:domain/status` - Toggle site status

### Files
- `GET /api/files/:domain` - List site files
- `POST /api/files/:domain` - Create file
- `DELETE /api/files/:domain/*` - Delete file
- `POST /api/files/:domain/upload` - Upload files
- `GET /api/files/usage` - Get disk usage

### Databases
- `GET /api/databases` - List databases
- `POST /api/databases` - Create database
- `DELETE /api/databases/:name` - Delete database
- `POST /api/databases/:name/query` - Execute query

### System
- `GET /api/system/stats` - Get server stats
- `GET /api/system/info` - Get server info
- `GET /api/system/network` - Get network info
- `GET /api/system/services` - Get service status
- `POST /api/system/nginx/reload` - Reload Nginx

## Management Commands

### Start/Stop Services

```bash
# Backend service
sudo systemctl start fedora-host-manager
sudo systemctl stop fedora-host-manager
sudo systemctl restart fedora-host-manager

# Nginx
sudo systemctl start nginx
sudo systemctl stop nginx
sudo systemctl restart nginx

# MariaDB
sudo systemctl start mariadb
sudo systemctl stop mariadb
sudo systemctl restart mariadb
```

### View Logs

```bash
# Backend logs
sudo journalctl -u fedora-host-manager -f

# Nginx logs
sudo tail -f /var/log/nginx/error.log

# Access logs
sudo tail -f /var/log/nginx/yourdomain_access.log
```

### Configuration Files

- **Backend Config**: `/workspace/fedora-host-manager/backend/.env`
- **Nginx Main**: `/etc/nginx/nginx.conf`
- **Manager Proxy**: `/etc/nginx/conf.d/manager.conf`
- **Site Configs**: `/etc/nginx/conf.d/`

## Security Recommendations

1. **Change Default Password**: Immediately change the admin password after first login
2. **Enable HTTPS**: Configure SSL certificates for the dashboard
3. **Firewall**: Ensure only necessary ports are open
4. **Regular Updates**: Keep your system and packages updated
5. **Strong Passwords**: Use strong passwords for database users

## Troubleshooting

### Backend Won't Start

Check the service status:
```bash
sudo systemctl status fedora-host-manager
sudo journalctl -u fedora-host-manager -n 50
```

### Nginx Configuration Error

Test the configuration:
```bash
sudo nginx -t
```

### Can't Access Dashboard

Check if the service is running:
```bash
sudo systemctl status fedora-host-manager
```

Check firewall:
```bash
sudo firewall-cmd --list-ports
```

### Domain Not Resolving

For local testing, verify `/etc/hosts`:
```bash
cat /etc/hosts | grep yourdomain
```

For external access, verify DNS propagation:
```bash
dig yourdomain.com
```

## Development

### Running in Development Mode

```bash
# Terminal 1 - Backend
cd backend
npm run dev

# Terminal 2 - Frontend
cd frontend
npm run dev
```

Access the frontend at http://localhost:5173 (proxies API to localhost:3000)

### Building for Production

```bash
# Build frontend
cd frontend
npm run build

# The built files will be in frontend/dist/
```

## Support

For issues and questions:
1. Check the troubleshooting section above
2. View service logs
3. Check Nginx error logs

## License

MIT License - Feel free to use and modify for your needs.

---

Made with ❤️ for the Fedora community
