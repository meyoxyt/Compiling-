#!/bin/bash

# Fedora Host Manager - Setup Script
# This script sets up your Fedora laptop as a web hosting server

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Print banner
print_banner() {
    echo -e "${BLUE}"
    echo "╔═══════════════════════════════════════════════════════════════╗"
    echo "║                                                               ║"
    echo "║   Fedora Host Manager - Setup Script                         ║"
    echo "║   ───────────────────────────────                            ║"
    echo "║                                                               ║"
    echo "║   Turn your Fedora laptop into a web hosting server          ║"
    echo "║                                                               ║"
    echo "╚═══════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

# Print status
print_status() {
    echo -e "${GREEN}[OK]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[!]${NC} $1"
}

print_error() {
    echo -e "${RED}[X]${NC} $1"
}

# Check if running as root
check_root() {
    if [[ $EUID -ne 0 ]]; then
        print_error "This script must be run as root (use sudo)"
        exit 1
    fi
}

# Update system
update_system() {
    print_status "Updating system packages..."
    dnf update -y
    print_status "System updated successfully"
}

# Install required packages
install_packages() {
    print_status "Installing required packages..."

    # Nginx and related
    dnf install -y nginx

    # PHP for PHP support
    dnf install -y php php-fpm php-mysqlnd php-json

    # MariaDB (MySQL replacement)
    dnf install -y mariadb-server mariadb

    # Node.js
    dnf install -y nodejs npm

    # Development tools
    dnf install -y git wget unzip

    # Firewall
    dnf install -y firewalld

    print_status "All packages installed successfully"
}

# Configure firewall
configure_firewall() {
    print_status "Configuring firewall..."

    # Start and enable firewall
    systemctl start firewalld
    systemctl enable firewalld

    # Allow HTTP, HTTPS, and custom ports
    firewall-cmd --permanent --add-service=http
    firewall-cmd --permanent --add-service=https
    firewall-cmd --permanent --add-port=3000/tcp

    # Reload firewall
    firewall-cmd --reload

    print_status "Firewall configured successfully"
}

# Configure Nginx
configure_nginx() {
    print_status "Configuring Nginx..."

    # Create directories
    mkdir -p /var/www/sites
    mkdir -p /var/log/nginx

    # Set permissions
    chown -R nginx:nginx /var/www/sites
    chmod -R 755 /var/www/sites

    # Backup original config
    if [[ ! -f /etc/nginx/nginx.conf.backup ]]; then
        cp /etc/nginx/nginx.conf /etc/nginx/nginx.conf.backup
    fi

    # Create manager config
    cat > /etc/nginx/conf.d/manager.conf << 'EOF'
server {
    listen 3000;
    server_name localhost;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
EOF

    # Start and enable Nginx
    systemctl start nginx
    systemctl enable nginx

    print_status "Nginx configured successfully"
}

# Configure PHP-FPM
configure_php() {
    print_status "Configuring PHP-FPM..."

    # Start and enable PHP-FPM
    systemctl start php-fpm
    systemctl enable php-fpm

    # Configure user group
    sed -i 's/^user = .*/user = nginx/' /etc/php-fpm.d/www.conf
    sed -i 's/^group = .*/group = nginx/' /etc/php-fpm.d/www.conf

    # Restart PHP-FPM
    systemctl restart php-fpm

    print_status "PHP-FPM configured successfully"
}

# Configure MariaDB
configure_mariadb() {
    print_status "Configuring MariaDB..."

    # Start and enable MariaDB
    systemctl start mariadb
    systemctl enable mariadb

    # Secure installation (non-interactive)
    mysql -e "UPDATE mysql.user SET Password = PASSWORD('') WHERE User = 'root';"
    mysql -e "DELETE FROM mysql.user WHERE User = '';"
    mysql -e "DELETE FROM mysql.db WHERE Db = 'test' OR Db = 'test\_%';"
    mysql -e "FLUSH PRIVILEGES;"

    print_status "MariaDB configured successfully"
}

# Setup backend
setup_backend() {
    print_status "Setting up backend..."

    cd /workspace/fedora-host-manager/backend

    # Install Node.js dependencies
    npm install

    # Create data directory
    mkdir -p /workspace/fedora-host-manager/backend/data

    # Copy environment file
    cp .env.example .env

    # Create systemd service
    cat > /etc/systemd/system/fedora-host-manager.service << 'EOF'
[Unit]
Description=Fedora Host Manager Backend
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/workspace/fedora-host-manager/backend
ExecStart=/usr/bin/node src/server.js
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

    # Reload systemd and enable service
    systemctl daemon-reload
    systemctl enable fedora-host-manager
    systemctl start fedora-host-manager

    print_status "Backend setup completed"
}

# Setup frontend
setup_frontend() {
    print_status "Setting up frontend..."

    cd /workspace/fedora-host-manager/frontend

    # Install Node.js dependencies
    npm install

    # Build frontend
    npm run build

    print_status "Frontend built successfully"
}

# Setup sample website
setup_sample_website() {
    print_status "Setting up sample website..."

    # Copy sample website to web root
    cp -r /workspace/fedora-host-manager/sample-website/* /var/www/sites/sample.local/

    # Set permissions
    chown -R nginx:nginx /var/www/sites
    chmod -R 755 /var/www/sites

    # Create Nginx config for sample site
    cat > /etc/nginx/conf.d/sample.local.conf << 'EOF'
server {
    listen 80;
    server_name sample.local www.sample.local;

    root /var/www/sites/sample.local;
    index index.html index.htm;

    access_log /var/log/nginx/sample.local_access.log;
    error_log /var/log/nginx/sample.local_error.log;

    location / {
        try_files $uri $uri/ =404;
    }
}
EOF

    print_status "Sample website configured"
}

# Test configuration
test_config() {
    print_status "Testing configuration..."

    # Test Nginx
    if nginx -t; then
        print_status "Nginx configuration is valid"
        systemctl reload nginx
    else
        print_error "Nginx configuration test failed"
    fi
}

# Print completion message
print_completion() {
    echo ""
    echo -e "${GREEN}╔═══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║                                                               ║${NC}"
    echo -e "${GREEN}║   Setup Complete!                                            ║${NC}"
    echo -e "${GREEN}║                                                               ║${NC}"
    echo -e "${GREEN}╚═══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${BLUE}Access Points:${NC}"
    echo -e "   Dashboard:   http://localhost:3000"
    echo -e "   Sample Site: http://sample.local"
    echo ""
    echo -e "${BLUE}Default Login:${NC}"
    echo -e "   Username: admin"
    echo -e "   Password: admin123"
    echo ""
    echo -e "${YELLOW}Important:${NC}"
    echo -e "   - Change default password after first login"
    echo -e "   - Add '127.0.0.1 sample.local' to /etc/hosts to test sample site"
    echo -e "   - For external access, configure your router and DNS"
    echo ""
}

# Main function
main() {
    print_banner

    check_root
    update_system
    install_packages
    configure_firewall
    configure_nginx
    configure_php
    configure_mariadb
    setup_backend
    setup_frontend
    setup_sample_website
    test_config
    print_completion
}

# Run main function
main "$@"
