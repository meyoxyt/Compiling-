const { getDb } = require('../services/databaseService');
const nginxService = require('../services/nginxService');
const fileService = require('../services/fileService');
const config = require('../utils/config');

exports.listSites = async (req, res) => {
  try {
    const db = getDb();
    const sites = db.prepare('SELECT * FROM sites ORDER BY created_at DESC').all();
    res.json(sites);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getSite = async (req, res) => {
  try {
    const db = getDb();
    const site = db.prepare('SELECT * FROM sites WHERE domain = ?').get(req.params.domain);

    if (!site) {
      return res.status(404).json({ error: 'Site not found' });
    }

    res.json(site);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.createSite = async (req, res) => {
  try {
    const { domain, port, php_version } = req.body;

    if (!domain) {
      return res.status(400).json({ error: 'Domain is required' });
    }

    // Validate domain format
    const domainRegex = /^[a-zA-Z0-9][a-zA-Z0-9-]*\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?$/;
    if (!domainRegex.test(domain)) {
      return res.status(400).json({ error: 'Invalid domain format' });
    }

    const documentRoot = `${config.webRoot}/${domain}`;

    const site = {
      domain,
      document_root: documentRoot,
      port: port || 80,
      php_version: php_version || null,
      ssl_enabled: 0,
      status: 'active'
    };

    const db = getDb();

    // Check if site already exists
    const existing = db.prepare('SELECT id FROM sites WHERE domain = ?').get(domain);
    if (existing) {
      return res.status(400).json({ error: 'Site with this domain already exists' });
    }

    // Create site directory
    await fileService.createSiteDirectory(domain);

    // Create nginx config
    const nginxResult = await nginxService.createSite(site);
    if (!nginxResult.success) {
      return res.status(500).json({ error: 'Failed to create nginx config', details: nginxResult.message });
    }

    // Save to database
    const result = db.prepare(`
      INSERT INTO sites (domain, document_root, port, php_version, status)
      VALUES (?, ?, ?, ?, ?)
    `).run(domain, documentRoot, site.port, site.php_version, site.status);

    // Log the action
    db.prepare('INSERT INTO logs (type, message) VALUES (?, ?)').run('site', `Created site: ${domain}`);

    res.status(201).json({
      message: 'Site created successfully',
      site: { id: result.lastInsertRowid, ...site }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.updateSite = async (req, res) => {
  try {
    const { domain } = req.params;
    const { port, php_version, status } = req.body;

    const db = getDb();
    const site = db.prepare('SELECT * FROM sites WHERE domain = ?').get(domain);

    if (!site) {
      return res.status(404).json({ error: 'Site not found' });
    }

    const updatedSite = {
      ...site,
      port: port || site.port,
      php_version: php_version || site.php_version,
      status: status || site.status
    };

    // Update nginx config
    const nginxResult = await nginxService.updateSite(updatedSite);
    if (!nginxResult.success) {
      return res.status(500).json({ error: 'Failed to update nginx config', details: nginxResult.message });
    }

    // Update database
    db.prepare(`
      UPDATE sites SET port = ?, php_version = ?, status = ?, updated_at = CURRENT_TIMESTAMP
      WHERE domain = ?
    `).run(updatedSite.port, updatedSite.php_version, updatedSite.status, domain);

    res.json({ message: 'Site updated successfully', site: updatedSite });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.deleteSite = async (req, res) => {
  try {
    const { domain } = req.params;

    const db = getDb();
    const site = db.prepare('SELECT * FROM sites WHERE domain = ?').get(domain);

    if (!site) {
      return res.status(404).json({ error: 'Site not found' });
    }

    // Delete nginx config
    await nginxService.deleteSite(domain);

    // Delete site files
    await fileService.deleteSiteDirectory(domain);

    // Delete from database
    db.prepare('DELETE FROM sites WHERE domain = ?').run(domain);

    // Log the action
    db.prepare('INSERT INTO logs (type, message) VALUES (?, ?)').run('site', `Deleted site: ${domain}`);

    res.json({ message: 'Site deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.toggleSiteStatus = async (req, res) => {
  try {
    const { domain } = req.params;
    const { status } = req.body;

    const db = getDb();
    const site = db.prepare('SELECT * FROM sites WHERE domain = ?').get(domain);

    if (!site) {
      return res.status(404).json({ error: 'Site not found' });
    }

    db.prepare('UPDATE sites SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE domain = ?')
      .run(status, domain);

    // Log the action
    db.prepare('INSERT INTO logs (type, message) VALUES (?, ?)').run('site', `Site ${domain} ${status}`);

    res.json({ message: `Site ${status} successfully` });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getSiteConfig = async (req, res) => {
  try {
    const { domain } = req.params;
    const config = await nginxService.getNginxConfig(domain);

    if (!config) {
      return res.status(404).json({ error: 'Configuration not found' });
    }

    res.json({ config });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
