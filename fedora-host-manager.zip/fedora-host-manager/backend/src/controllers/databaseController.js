const mysqlService = require('../services/mysqlService');
const { getDb } = require('../services/databaseService');

exports.listDatabases = async (req, res) => {
  try {
    const databases = await mysqlService.listDatabases();
    res.json(databases || []);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.createDatabase = async (req, res) => {
  try {
    const { domain, db_name, db_user, db_password } = req.body;

    if (!domain || !db_name || !db_user || !db_password) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    // Generate random password if not provided
    const password = db_password || generateRandomPassword();

    const result = await mysqlService.createDatabase(domain, db_name, db_user, password);

    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    // Save to app database
    const db = getDb();
    db.prepare(`
      INSERT INTO databases (site_id, db_name, db_user, db_password)
      VALUES ((SELECT id FROM sites WHERE domain = ?), ?, ?, ?)
    `).run(domain, db_name, db_user, password);

    res.status(201).json({
      message: 'Database created successfully',
      details: { db_name, db_user, db_password: password }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.deleteDatabase = async (req, res) => {
  try {
    const { db_name } = req.params;

    const db = getDb();
    const database = db.prepare('SELECT * FROM databases WHERE db_name = ?').get(db_name);

    if (!database) {
      return res.status(404).json({ error: 'Database not found' });
    }

    const result = await mysqlService.deleteDatabase(db_name, database.db_user);

    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    // Remove from app database
    db.prepare('DELETE FROM databases WHERE db_name = ?').run(db_name);

    res.json({ message: 'Database deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.executeQuery = async (req, res) => {
  try {
    const { db_name } = req.params;
    const { query } = req.body;

    if (!query) {
      return res.status(400).json({ error: 'Query required' });
    }

    // Security check - only allow SELECT queries
    const normalizedQuery = query.trim().toUpperCase();
    if (!normalizedQuery.startsWith('SELECT') && !normalizedQuery.startsWith('SHOW')) {
      return res.status(403).json({ error: 'Only SELECT and SHOW queries are allowed' });
    }

    const result = await mysqlService.executeQuery(db_name, query);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.testConnection = async (req, res) => {
  try {
    const result = await mysqlService.testConnection();
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getDatabaseSize = async (req, res) => {
  try {
    const { db_name } = req.params;
    const size = await mysqlService.getDatabaseSize(db_name);
    res.json({ size_mb: size });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

function generateRandomPassword() {
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
  let password = '';
  for (let i = 0; i < 16; i++) {
    password += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return password;
}
