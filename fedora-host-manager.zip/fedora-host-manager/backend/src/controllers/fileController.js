const fileService = require('../services/fileService');
const fs = require('fs');
const path = require('path');
const config = require('../utils/config');

exports.listFiles = async (req, res) => {
  try {
    const { domain } = req.params;
    const files = await fileService.listFiles(domain);
    res.json(files);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getFileContent = async (req, res) => {
  try {
    const { domain, '*': filePath } = req.params;
    const content = await fileService.getFileContent(domain, filePath);

    if (content === null) {
      return res.status(404).json({ error: 'File not found' });
    }

    res.json({ content });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.createFile = async (req, res) => {
  try {
    const { domain } = req.params;
    const { filePath, content } = req.body;

    if (!filePath || content === undefined) {
      return res.status(400).json({ error: 'File path and content required' });
    }

    const result = await fileService.createFile(domain, filePath, content);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.deleteFile = async (req, res) => {
  try {
    const { domain, '*': filePath } = req.params;

    if (!filePath) {
      return res.status(400).json({ error: 'File path required' });
    }

    const result = await fileService.deleteFile(domain, filePath);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.uploadFile = async (req, res) => {
  try {
    const { domain } = req.params;

    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ error: 'No files uploaded' });
    }

    const uploaded = [];
    for (const file of req.files) {
      const sitePath = path.join(config.webRoot, domain);
      const destPath = path.join(sitePath, file.originalname);

      // Ensure directory exists
      const dir = path.dirname(destPath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }

      fs.renameSync(file.path, destPath);
      uploaded.push(file.originalname);
    }

    res.json({ message: 'Files uploaded successfully', uploaded });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getDiskUsage = async (req, res) => {
  try {
    const usage = await fileService.getDiskUsage();
    res.json(usage);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.downloadFile = async (req, res) => {
  try {
    const { domain, '*': filePath } = req.params;
    const fullPath = path.join(config.webRoot, domain, filePath);

    if (!fs.existsSync(fullPath)) {
      return res.status(404).json({ error: 'File not found' });
    }

    if (fs.statSync(fullPath).isDirectory()) {
      return res.status(400).json({ error: 'Cannot download directory' });
    }

    res.download(fullPath);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
