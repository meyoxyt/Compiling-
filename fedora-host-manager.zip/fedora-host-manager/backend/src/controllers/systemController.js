const { exec, execSync } = require('child_process');
const os = require('os');
const { getDb } = require('../services/databaseService');
const nginxService = require('../services/nginxService');

exports.getSystemStats = async (req, res) => {
  try {
    const stats = {
      cpu: os.cpus().length,
      memory: {
        total: Math.round(os.totalmem() / 1024 / 1024 / 1024) + ' GB',
        free: Math.round(os.freemem() / 1024 / 1024 / 1024) + ' GB',
        usedPercent: ((1 - os.freemem() / os.totalmem()) * 100).toFixed(1)
      },
      uptime: formatUptime(os.uptime()),
      hostname: os.hostname(),
      platform: os.platform() + ' ' + os.release()
    };

    res.json(stats);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getNginxStatus = async (req, res) => {
  try {
    const status = await nginxService.getNginxStatus();
    res.json(status);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.reloadNginx = async (req, res) => {
  try {
    const result = await nginxService.reloadNginx();
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.testNginxConfig = async (req, res) => {
  try {
    const result = await nginxService.testConfig();
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getLogs = async (req, res) => {
  try {
    const db = getDb();
    const { type, limit = 50 } = req.query;

    let query = 'SELECT * FROM logs';
    const params = [];

    if (type) {
      query += ' WHERE type = ?';
      params.push(type);
    }

    query += ' ORDER BY created_at DESC LIMIT ?';
    params.push(parseInt(limit));

    const logs = db.prepare(query).all(...params);
    res.json(logs);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.clearLogs = async (req, res) => {
  try {
    const db = getDb();
    db.prepare('DELETE FROM logs').run();
    res.json({ message: 'Logs cleared successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getServices = async (req, res) => {
  try {
    const services = ['nginx', 'mariadb', 'php-fpm', 'firewalld'];
    const status = {};

    for (const service of services) {
      try {
        const output = execSync(`systemctl is-active ${service}`, { encoding: 'utf8' }).trim();
        status[service] = {
          active: output === 'active',
          status: output
        };
      } catch (e) {
        status[service] = {
          active: false,
          status: 'not found'
        };
      }
    }

    res.json(status);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.restartService = async (req, res) => {
  try {
    const { service } = req.body;

    if (!service) {
      return res.status(400).json({ error: 'Service name required' });
    }

    execSync(`systemctl restart ${service}`, { encoding: 'utf8' });
    res.json({ message: `${service} restarted successfully` });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getNetworkInfo = async (req, res) => {
  try {
    const interfaces = os.networkInterfaces();
    const networks = [];

    for (const name of Object.keys(interfaces)) {
      for (const iface of interfaces[name]) {
        if (iface.family === 'IPv4' && !iface.internal) {
          networks.push({
            name,
            ip: iface.address,
            mac: iface.mac
          });
        }
      }
    }

    res.json(networks);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getServerInfo = async (req, res) => {
  try {
    const info = {
      os: `${os.type()} ${os.release()}`,
      hostname: os.hostname(),
      uptime: formatUptime(os.uptime()),
      cpu: {
        cores: os.cpus().length,
        model: os.cpus()[0]?.model || 'Unknown'
      },
      memory: {
        total: Math.round(os.totalmem() / 1024 / 1024 / 1024) + ' GB',
        free: Math.round(os.freemem() / 1024 / 1024 / 1024) + ' GB'
      }
    };

    res.json(info);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

function formatUptime(seconds) {
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);

  if (days > 0) {
    return `${days}d ${hours}h ${minutes}m`;
  } else if (hours > 0) {
    return `${hours}h ${minutes}m`;
  }
  return `${minutes}m`;
}
