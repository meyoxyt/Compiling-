const express = require('express');
const router = express.Router();
const databaseController = require('../controllers/databaseController');
const { authenticateToken } = require('../middleware/auth');

// All routes require authentication
router.use(authenticateToken);

// Database operations
router.get('/', databaseController.listDatabases);
router.post('/', databaseController.createDatabase);
router.delete('/:db_name', databaseController.deleteDatabase);
router.get('/:db_name/size', databaseController.getDatabaseSize);
router.post('/:db_name/query', databaseController.executeQuery);

// MySQL connection test
router.get('/test/connection', databaseController.testConnection);

module.exports = router;
