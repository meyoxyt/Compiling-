const express = require('express');
const router = express.Router();
const siteController = require('../controllers/siteController');
const { authenticateToken } = require('../middleware/auth');
const multer = require('multer');

// Configure multer for file uploads
const upload = multer({ dest: '/tmp/uploads' });

// All routes require authentication
router.use(authenticateToken);

// Site CRUD operations
router.get('/', siteController.listSites);
router.post('/', siteController.createSite);
router.get('/:domain', siteController.getSite);
router.put('/:domain', siteController.updateSite);
router.delete('/:domain', siteController.deleteSite);

// Site status management
router.put('/:domain/status', siteController.toggleSiteStatus);

// Site configuration
router.get('/:domain/config', siteController.getSiteConfig);

// File operations for a site
router.get('/:domain/files', siteController.listSites);
router.post('/:domain/files', upload.array('files'), siteController.listSites);

module.exports = router;
