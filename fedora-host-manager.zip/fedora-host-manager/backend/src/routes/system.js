const express = require('express');
const router = express.Router();
const systemController = require('../controllers/systemController');
const { authenticateToken } = require('../middleware/auth');

// All routes require authentication
router.use(authenticateToken);

// System monitoring
router.get('/stats', systemController.getSystemStats);
router.get('/info', systemController.getServerInfo);
router.get('/network', systemController.getNetworkInfo);
router.get('/services', systemController.getServices);

// Nginx management
router.get('/nginx/status', systemController.getNginxStatus);
router.post('/nginx/reload', systemController.reloadNginx);
router.post('/nginx/test', systemController.testNginxConfig);

// Service management
router.post('/services/restart', systemController.restartService);

// Logs
router.get('/logs', systemController.getLogs);
router.delete('/logs', systemController.clearLogs);

module.exports = router;
