const express = require('express');
const router = express.Router();
const fileController = require('../controllers/fileController');
const { authenticateToken } = require('../middleware/auth');
const multer = require('multer');

const upload = multer({ dest: '/tmp/uploads' });

// All routes require authentication
router.use(authenticateToken);

// File operations
router.get('/usage', fileController.getDiskUsage);
router.get('/:domain', fileController.listFiles);
router.get('/:domain/*', fileController.getFileContent);
router.post('/:domain', fileController.createFile);
router.put('/:domain/*', fileController.createFile);
router.delete('/:domain/*', fileController.deleteFile);
router.post('/:domain/upload', upload.array('files'), fileController.uploadFile);
router.get('/:domain/download/*', fileController.downloadFile);

module.exports = router;
