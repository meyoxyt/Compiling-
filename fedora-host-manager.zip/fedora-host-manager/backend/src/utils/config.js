require('dotenv').config();

const config = {
  port: process.env.PORT || 3000,
  nodeEnv: process.env.NODE_ENV || 'development',
  jwtSecret: process.env.JWT_SECRET || 'default-secret-change-in-production',
  dbPath: process.env.DB_PATH || './data/hosting.db',
  nginxConfigPath: process.env.NGINX_CONFIG_PATH || '/etc/nginx/conf.d',
  nginxSitesPath: process.env.NGINX_SITES_PATH || '/etc/nginx/sites-enabled',
  webRoot: process.env.WEB_ROOT || '/var/www/sites',
  adminUsername: process.env.ADMIN_USERNAME || 'admin',
  adminPassword: process.env.ADMIN_PASSWORD || 'admin123',
  mysqlHost: process.env.MYSQL_HOST || 'localhost',
  mysqlUser: process.env.MYSQL_USER || 'root',
  mysqlPassword: process.env.MYSQL_PASSWORD || ''
};

module.exports = config;
