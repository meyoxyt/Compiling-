const mysql = require('mysql2/promise');
const config = require('../utils/config');

let pool = null;

function getPool() {
  if (!pool) {
    pool = mysql.createPool({
      host: config.mysqlHost,
      user: config.mysqlUser,
      password: config.mysqlPassword,
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0
    });
  }
  return pool;
}

class MySQLService {
  async createDatabase(siteDomain, dbName, dbUser, dbPassword) {
    try {
      const connection = await getPool().getConnection();

      // Create database
      await connection.execute(`CREATE DATABASE IF NOT EXISTS \`${dbName}\``);

      // Create user and grant privileges
      await connection.execute(`CREATE USER IF NOT EXISTS '${dbUser}'@'localhost' IDENTIFIED BY '${dbPassword}'`);
      await connection.execute(`GRANT ALL PRIVILEGES ON \`${dbName}\`.* TO '${dbUser}'@'localhost'`);
      await connection.execute('FLUSH PRIVILEGES');

      connection.release();

      return {
        success: true,
        message: `Database ${dbName} created successfully`,
        details: { dbName, dbUser }
      };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  async deleteDatabase(dbName, dbUser) {
    try {
      const connection = await getPool().getConnection();

      await connection.execute(`DROP DATABASE IF EXISTS \`${dbName}\``);
      await connection.execute(`DROP USER IF EXISTS '${dbUser}'@'localhost'`);

      connection.release();

      return { success: true, message: `Database ${dbName} deleted successfully` };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  async listDatabases() {
    try {
      const [rows] = await getPool().execute("SHOW DATABASES");
      const systemDatabases = ['information_schema', 'mysql', 'performance_schema', 'sys'];

      return rows
        .map(row => row.Database)
        .filter(db => !systemDatabases.includes(db));
    } catch (error) {
      return { error: error.message };
    }
  }

  async getDatabaseSize(dbName) {
    try {
      const [rows] = await getPool().execute(
        `SELECT ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) AS size_mb
         FROM information_schema.tables
         WHERE table_schema = ?`,
        [dbName]
      );
      return rows[0]?.size_mb || 0;
    } catch (error) {
      return 0;
    }
  }

  async executeQuery(dbName, query) {
    try {
      const connection = await getPool().connect();
      await connection.changeUser({ database: dbName });
      const [results] = await connection.execute(query);
      connection.release();

      return { success: true, results };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  async testConnection() {
    try {
      const connection = await getPool().getConnection();
      await connection.ping();
      connection.release();
      return { success: true, connected: true };
    } catch (error) {
      return { success: false, connected: false, error: error.message };
    }
  }
}

module.exports = new MySQLService();
