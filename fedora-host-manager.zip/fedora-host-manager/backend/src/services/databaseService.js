const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const config = require('../utils/config');

let db;

function initializeDatabase() {
  const dbDir = path.dirname(config.dbPath);
  if (!fs.existsSync(dbDir)) {
    fs.mkdirSync(dbDir, { recursive: true });
  }

  db = new Database(config.dbPath);
  db.pragma('journal_mode = WAL');

  // Create tables
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      email TEXT,
      role TEXT DEFAULT 'admin',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      last_login DATETIME
    );

    CREATE TABLE IF NOT EXISTS sites (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      domain TEXT UNIQUE NOT NULL,
      document_root TEXT NOT NULL,
      port INTEGER DEFAULT 80,
      ssl_enabled INTEGER DEFAULT 0,
      ssl_cert_path TEXT,
      ssl_key_path TEXT,
      php_version TEXT,
      status TEXT DEFAULT 'active',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS databases (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      site_id INTEGER,
      db_name TEXT UNIQUE NOT NULL,
      db_user TEXT NOT NULL,
      db_password TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (site_id) REFERENCES sites(id)
    );

    CREATE TABLE IF NOT EXISTS logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      type TEXT NOT NULL,
      message TEXT NOT NULL,
      details TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT
    );
  `);

  // Create default admin user if not exists
  const adminExists = db.prepare('SELECT id FROM users WHERE username = ?').get(config.adminUsername);
  if (!adminExists) {
    const hashedPassword = bcrypt.hashSync(config.adminPassword, 10);
    db.prepare(`
      INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, ?)
    `).run(config.adminUsername, hashedPassword, 'admin@localhost', 'admin');
    console.log('Default admin user created');
  }

  return db;
}

function getDb() {
  if (!db) {
    initializeDatabase();
  }
  return db;
}

module.exports = {
  initializeDatabase,
  getDb
};
