const { exec, execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const config = require('../utils/config');

class NginxService {
  constructor() {
    this.configPath = config.nginxConfigPath;
    this.sitesPath = config.nginxSitesPath;
  }

  generateSiteConfig(site) {
    const sslConfig = site.ssl_enabled ? `
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    ssl_certificate ${site.ssl_cert_path};
    ssl_certificate_key ${site.ssl_key_path};
    ssl_session_timeout 1d;
    ssl_session_cache shared:SSL:50m;
    ssl_session_tickets off;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384;
    ssl_prefer_server_ciphers off;
    add_header Strict-Transport-Security "max-age=63072000" always;` : '';

    return `
server {
    listen ${site.port}${site.ssl_enabled ? ' ssl http2' : ''};
    listen [::]:${site.port}${site.ssl_enabled ? ' ssl http2' : ''};

    server_name ${site.domain} www.${site.domain};

    root ${site.document_root};
    index index.html index.htm index.php;

    access_log /var/log/nginx/${site.domain}_access.log;
    error_log /var/log/nginx/${site.domain}_error.log;

    location / {
        try_files $uri $uri/ =404;
    }

    location ~ \.php$ {
        fastcgi_pass unix:/run/php-fpm/www.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }

    location ~ /\.ht {
        deny all;
    }${sslConfig}
}
`;
  }

  async createSite(site) {
    const configFile = path.join(this.configPath, `${site.domain}.conf`);
    const configContent = this.generateSiteConfig(site);

    // Create document root directory
    fs.mkdirSync(site.document_root, { recursive: true });

    // Write nginx config
    fs.writeFileSync(configFile, configContent);

    // Reload nginx
    return this.reloadNginx();
  }

  async updateSite(site) {
    const configFile = path.join(this.configPath, `${site.domain}.conf`);
    const configContent = this.generateSiteConfig(site);
    fs.writeFileSync(configFile, configContent);
    return this.reloadNginx();
  }

  async deleteSite(domain) {
    const configFile = path.join(this.configPath, `${domain}.conf`);

    if (fs.existsSync(configFile)) {
      fs.unlinkSync(configFile);
    }

    return this.reloadNginx();
  }

  async reloadNginx() {
    try {
      execSync('nginx -t', { encoding: 'utf8' });
      execSync('systemctl reload nginx', { encoding: 'utf8' });
      return { success: true, message: 'Nginx reloaded successfully' };
    } catch (error) {
      // Rollback config
      return { success: false, message: error.message };
    }
  }

  async getNginxStatus() {
    try {
      const output = execSync('systemctl is-active nginx', { encoding: 'utf8' }).trim();
      return { active: output === 'active' };
    } catch (error) {
      return { active: false };
    }
  }

  async getNginxConfig(domain) {
    const configFile = path.join(this.configPath, `${domain}.conf`);
    if (fs.existsSync(configFile)) {
      return fs.readFileSync(configFile, 'utf8');
    }
    return null;
  }

  async testConfig() {
    try {
      const output = execSync('nginx -t', { encoding: 'utf8' });
      return { success: true, output };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }
}

module.exports = new NginxService();
