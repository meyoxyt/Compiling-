const fs = require('fs');
const path = require('path');
const config = require('../utils/config');

class FileService {
  constructor() {
    this.webRoot = config.webRoot;
  }

  async createSiteDirectory(domain) {
    const sitePath = path.join(this.webRoot, domain);
    if (!fs.existsSync(sitePath)) {
      fs.mkdirSync(sitePath, { recursive: true });
    }
    return sitePath;
  }

  async deleteSiteDirectory(domain) {
    const sitePath = path.join(this.webRoot, domain);
    if (fs.existsSync(sitePath)) {
      fs.rmSync(sitePath, { recursive: true, force: true });
    }
  }

  async listFiles(domain) {
    const sitePath = path.join(this.webRoot, domain);

    if (!fs.existsSync(sitePath)) {
      return [];
    }

    const files = [];
    const traverseDir = (dir, basePath = '') => {
      const items = fs.readdirSync(dir);
      items.forEach(item => {
        const fullPath = path.join(dir, item);
        const relativePath = path.join(basePath, item);
        const stats = fs.statSync(fullPath);

        if (stats.isDirectory()) {
          files.push({
            name: item,
            path: relativePath,
            type: 'directory',
            size: 0,
            modified: stats.mtime
          });
          traverseDir(fullPath, relativePath);
        } else {
          files.push({
            name: item,
            path: relativePath,
            type: 'file',
            size: this.formatSize(stats.size),
            sizeBytes: stats.size,
            modified: stats.mtime
          });
        }
      });
    };

    traverseDir(sitePath);
    return files;
  }

  formatSize(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  async createFile(domain, filePath, content) {
    const fullPath = path.join(this.webRoot, domain, filePath);
    const dir = path.dirname(fullPath);

    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    fs.writeFileSync(fullPath, content);
    return { success: true, path: filePath };
  }

  async deleteFile(domain, filePath) {
    const fullPath = path.join(this.webRoot, domain, filePath);

    if (fs.existsSync(fullPath)) {
      if (fs.statSync(fullPath).isDirectory()) {
        fs.rmSync(fullPath, { recursive: true });
      } else {
        fs.unlinkSync(fullPath);
      }
      return { success: true };
    }

    return { success: false, error: 'File not found' };
  }

  async getFileContent(domain, filePath) {
    const fullPath = path.join(this.webRoot, domain, filePath);

    if (fs.existsSync(fullPath) && fs.statSync(fullPath).isFile()) {
      return fs.readFileSync(fullPath, 'utf8');
    }

    return null;
  }

  async getDiskUsage() {
    try {
      const stats = fs.statfsSync(this.webRoot);
      const total = stats.bsize * stats.blocks;
      const available = stats.bsize * stats.bavail;
      const used = total - available;

      return {
        total: this.formatSize(total),
        used: this.formatSize(used),
        available: this.formatSize(available),
        percentUsed: ((used / total) * 100).toFixed(2)
      };
    } catch (error) {
      return { error: error.message };
    }
  }

  async extractZip(domain, zipPath) {
    // Placeholder for zip extraction logic
    // Would require adm-zip or similar package
    return { success: true, message: 'Zip extraction not implemented' };
  }
}

module.exports = new FileService();
