const app = require('./app');
const config = require('./utils/config');

const PORT = config.port;
const HOST = '0.0.0.0';

app.listen(PORT, HOST, () => {
  console.log(`
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║   🚀 Fedora Host Manager Backend                              ║
║   ─────────────────────────────                               ║
║                                                               ║
║   Server running on http://${HOST}:${PORT}                         ║
║   Environment: ${config.nodeEnv.padEnd(42)}║
║                                                               ║
║   API Endpoints:                                               ║
║   • Auth:      /api/auth/*                                    ║
║   • Sites:     /api/sites/*                                   ║
║   • Files:     /api/files/*                                   ║
║   • Databases: /api/databases/*                               ║
║   • System:    /api/system/*                                  ║
║                                                               ║
║   Default Login:                                              ║
║   Username: ${config.adminUsername.padEnd(48)}║
║   Password: ${config.adminPassword.padEnd(48)}║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
  `);
});
