package com.eliteeconomyhook.providers;

import com.eliteeconomyhook.ELITEEconomyHook;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Simple Vault economy provider implementation
 */
public class EcoProvider implements Economy {

    private final ELITEEconomyHook plugin;
    private final NumberFormat numberFormat;
    
    // Economy settings
    private double startBalance;
    private double maxBalance;
    private double minBalance;
    private boolean allowNegative;

    public EcoProvider(ELITEEconomyHook plugin) {
        this.plugin = plugin;
        this.numberFormat = NumberFormat.getNumberInstance(Locale.US);
        loadSettings();
    }

    private void loadSettings() {
        startBalance = plugin.getConfig().getDouble("start-balance", 0.0);
        maxBalance = plugin.getConfig().getDouble("max-balance", -1.0);
        minBalance = plugin.getConfig().getDouble("min-balance", 0.0);
        allowNegative = plugin.getConfig().getBoolean("allow-negative", false);
        numberFormat.setMinimumFractionDigits(2);
        numberFormat.setMaximumFractionDigits(2);
    }

    @Override
    public boolean isEnabled() { return plugin.isVaultHooked() && plugin.isEnabled(); }
    @Override
    public String getName() { return "ELITEEconomyHook"; }
    @Override
    public boolean hasBankSupport() { return false; }
    @Override
    public int fractionalDigits() { return 2; }

    @Override
    public String format(double amount) {
        return numberFormat.format(amount) + " Coins";
    }

    @Override
    public String currencyNamePlural() { return "Coins"; }
    @Override
    public String currencyNameSingular() { return "Coin"; }

    @Override
    public boolean hasAccount(String playerName) {
        OfflinePlayer player = Bukkit.getOfflinePlayer(playerName);
        return player.hasPlayedBefore() || player.isOnline();
    }

    @Override
    public boolean hasAccount(String playerName, String worldName) {
        // Economy is server-wide, world parameter is ignored
        return hasAccount(playerName);
    }

    @Override
    public boolean hasAccount(OfflinePlayer player) {
        return player.hasPlayedBefore() || player.isOnline();
    }

    @Override
    public boolean hasAccount(OfflinePlayer player, String worldName) {
        // Economy is server-wide, world parameter is ignored
        return hasAccount(player);
    }

    @Override
    public double getBalance(OfflinePlayer player) {
        if (player == null) return 0.0;
        String playerId = player.getUniqueId().toString();
        
        Double cached = plugin.getCachedBalance(playerId);
        if (cached != null) return cached;
        
        double balance = loadBalance(playerId);
        if (player.isOnline()) plugin.updateCachedBalance(playerId, balance);
        return balance;
    }

    @Override
    public double getBalance(OfflinePlayer player, String worldName) {
        // Economy is server-wide, world parameter is ignored
        return getBalance(player);
    }

    @Override
    public double getBalance(String playerName) {
        return getBalance(Bukkit.getOfflinePlayer(playerName));
    }

    @Override
    public double getBalance(String playerName, String worldName) {
        // Economy is server-wide, world parameter is ignored
        return getBalance(playerName);
    }

    @Override
    public boolean has(OfflinePlayer player, double amount) {
        return getBalance(player) >= amount;
    }

    @Override
    public boolean has(OfflinePlayer player, String worldName, double amount) {
        // Economy is server-wide, world parameter is ignored
        return has(player, amount);
    }

    @Override
    public boolean has(String playerName, double amount) {
        return has(Bukkit.getOfflinePlayer(playerName), amount);
    }

    @Override
    public boolean has(String playerName, String worldName, double amount) {
        // Economy is server-wide, world parameter is ignored
        return has(playerName, amount);
    }

    @Override
    public EconomyResponse depositPlayer(OfflinePlayer player, double amount) {
        if (player == null) {
            return new EconomyResponse(0, 0, EconomyResponse.ResponseType.FAILURE, "Player not found");
        }
        if (amount < 0) {
            return new EconomyResponse(0, 0, EconomyResponse.ResponseType.FAILURE, "Cannot deposit negative amount");
        }
        
        String playerId = player.getUniqueId().toString();
        double currentBalance = getBalance(player);
        double newBalance = currentBalance + amount;
        
        if (maxBalance >= 0 && newBalance > maxBalance) {
            return new EconomyResponse(0, currentBalance, EconomyResponse.ResponseType.FAILURE, "Maximum balance exceeded");
        }
        
        plugin.updateCachedBalance(playerId, newBalance);
        plugin.savePlayerBalance(playerId, newBalance);
        return new EconomyResponse(amount, newBalance, EconomyResponse.ResponseType.SUCCESS, null);
    }

    @Override
    public EconomyResponse depositPlayer(OfflinePlayer player, String worldName, double amount) {
        // Economy is server-wide, world parameter is ignored
        return depositPlayer(player, amount);
    }

    @Override
    public EconomyResponse depositPlayer(String playerName, double amount) {
        return depositPlayer(Bukkit.getOfflinePlayer(playerName), amount);
    }

    @Override
    public EconomyResponse depositPlayer(String playerName, String worldName, double amount) {
        // Economy is server-wide, world parameter is ignored
        return depositPlayer(playerName, amount);
    }

    @Override
    public EconomyResponse withdrawPlayer(OfflinePlayer player, double amount) {
        if (player == null) {
            return new EconomyResponse(0, 0, EconomyResponse.ResponseType.FAILURE, "Player not found");
        }
        if (amount < 0) {
            return new EconomyResponse(0, 0, EconomyResponse.ResponseType.FAILURE, "Cannot withdraw negative amount");
        }
        
        String playerId = player.getUniqueId().toString();
        double currentBalance = getBalance(player);
        
        if (currentBalance < amount) {
            return new EconomyResponse(0, currentBalance, EconomyResponse.ResponseType.FAILURE, "Insufficient funds");
        }
        
        double newBalance = currentBalance - amount;
        if (!allowNegative && newBalance < minBalance) {
            return new EconomyResponse(0, currentBalance, EconomyResponse.ResponseType.FAILURE, "Minimum balance is: " + minBalance);
        }
        
        plugin.updateCachedBalance(playerId, newBalance);
        plugin.savePlayerBalance(playerId, newBalance);
        return new EconomyResponse(amount, newBalance, EconomyResponse.ResponseType.SUCCESS, null);
    }

    @Override
    public EconomyResponse withdrawPlayer(String playerName, double amount) {
        return withdrawPlayer(Bukkit.getOfflinePlayer(playerName), amount);
    }

    @Override
    public EconomyResponse withdrawPlayer(OfflinePlayer player, String worldName, double amount) {
        // Economy is server-wide, world parameter is ignored
        return withdrawPlayer(player, amount);
    }

    @Override
    public EconomyResponse withdrawPlayer(String playerName, String worldName, double amount) {
        // Economy is server-wide, world parameter is ignored
        return withdrawPlayer(playerName, amount);
    }

    @Override
    public EconomyResponse createBank(String name, String player) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "Banks not supported");
    }

    @Override
    public EconomyResponse createBank(String name, OfflinePlayer player) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "Banks not supported");
    }

    @Override
    public EconomyResponse deleteBank(String name) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "Banks not supported");
    }

    @Override
    public EconomyResponse bankBalance(String name) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "Banks not supported");
    }

    @Override
    public EconomyResponse bankHas(String name, double amount) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "Banks not supported");
    }

    @Override
    public EconomyResponse bankWithdraw(String name, double amount) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "Banks not supported");
    }

    @Override
    public EconomyResponse bankDeposit(String name, double amount) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "Banks not supported");
    }

    @Override
    public EconomyResponse isBankOwner(String name, String playerName) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "Banks not supported");
    }

    @Override
    public EconomyResponse isBankOwner(String name, OfflinePlayer player) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "Banks not supported");
    }

    @Override
    public EconomyResponse isBankMember(String name, String playerName) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "Banks not supported");
    }

    @Override
    public EconomyResponse isBankMember(String name, OfflinePlayer player) {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "Banks not supported");
    }

    @Override
    public List<String> getBanks() { return new ArrayList<>(); }

    @Override
    public boolean createPlayerAccount(OfflinePlayer player) {
        if (hasAccount(player)) return false;
        String playerId = player.getUniqueId().toString();
        plugin.updateCachedBalance(playerId, startBalance);
        plugin.savePlayerBalance(playerId, startBalance);
        return true;
    }

    @Override
    public boolean createPlayerAccount(String playerName) {
        return createPlayerAccount(Bukkit.getOfflinePlayer(playerName));
    }

    @Override
    public boolean createPlayerAccount(OfflinePlayer player, String worldName) {
        // Economy is server-wide, world parameter is ignored
        return createPlayerAccount(player);
    }

    @Override
    public boolean createPlayerAccount(String playerName, String worldName) {
        // Economy is server-wide, world parameter is ignored
        return createPlayerAccount(playerName);
    }

    private double loadBalance(String playerId) {
        // Use main class's database loading
        return plugin.loadPlayerBalance(playerId);
    }
}
