package com.eliteeconomyhook;

import com.eliteeconomyhook.providers.EcoProvider;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.ServicePriority;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * ELITEEconomyHook - A lightweight Vault-compatible economy provider
 * Works on Minecraft 1.8+ servers (Bukkit, Spigot, PaperMC, Folia)
 */
public final class ELITEEconomyHook extends JavaPlugin implements Listener {

    private static ELITEEconomyHook instance;
    private EcoProvider economyProvider;
    private final ConcurrentHashMap<String, Double> playerBalances = new ConcurrentHashMap<>();
    private boolean vaultHooked = false;
    private Connection database;
    private Path databasePath;
    private Path backupPath;

    @Override
    public void onLoad() {
        instance = this;
        saveDefaultConfig();
        setupDatabase();
    }

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);
        setupEconomy();
        getLogger().info("ELITEEconomyHook enabled - " + (vaultHooked ? "Vault hooked" : "Vault NOT found"));
    }

    @Override
    public void onDisable() {
        createBackup();
        closeDatabase();
        playerBalances.clear();
        if (vaultHooked && economyProvider != null) {
            Bukkit.getServicesManager().unregister(economyProvider);
        }
    }

    private void setupDatabase() {
        Path dbFolder = getDataFolder().toPath().resolve("database");
        try {
            Files.createDirectories(dbFolder);
        } catch (IOException e) {
            getLogger().log(Level.SEVERE, "Failed to create database folder", e);
            return;
        }
        
        databasePath = dbFolder.resolve("economy.db");
        
        try {
            Class.forName("org.sqlite.JDBC");
            database = DriverManager.getConnection("jdbc:sqlite:" + databasePath.toAbsolutePath());
            database.createStatement().execute("CREATE TABLE IF NOT EXISTS balances (player_id TEXT PRIMARY KEY, balance REAL)");
        } catch (Exception e) {
            getLogger().log(Level.SEVERE, "Failed to initialize database", e);
        }
        
        Path serverRoot = getServer().getWorldContainer().toPath().getParent();
        backupPath = serverRoot.resolve("economybackup");
        try {
            Files.createDirectories(backupPath);
        } catch (IOException e) {
            getLogger().log(Level.WARNING, "Failed to create backup folder", e);
        }
    }

    private void createBackup() {
        if (database == null || databasePath == null) return;
        
        try {
            if (!database.isClosed()) database.close();
            
            Path backupFile = backupPath.resolve("economy_backup_" + System.currentTimeMillis() + ".db");
            Files.copy(databasePath, backupFile, StandardCopyOption.REPLACE_EXISTING);
            
            Path latestBackup = backupPath.resolve("economy_latest.db");
            Files.copy(databasePath, latestBackup, StandardCopyOption.REPLACE_EXISTING);
            
            getLogger().info("Backup created: " + backupFile.getFileName());
            database = DriverManager.getConnection("jdbc:sqlite:" + databasePath.toAbsolutePath());
        } catch (Exception e) {
            getLogger().log(Level.WARNING, "Failed to create backup", e);
        }
    }

    private void closeDatabase() {
        if (database != null) {
            try {
                if (!database.isClosed()) database.close();
            } catch (SQLException e) {
                getLogger().log(Level.WARNING, "Failed to close database", e);
            }
        }
    }

    private void setupEconomy() {
        if (Bukkit.getPluginManager().getPlugin("Vault") == null) {
            getLogger().severe("Vault not found! Economy features disabled.");
            vaultHooked = false;
            return;
        }
        
        economyProvider = new EcoProvider(this);
        RegisteredServiceProvider<Economy> rsp = Bukkit.getServicesManager().getRegistration(Economy.class);
        if (rsp != null) {
            Bukkit.getServicesManager().unregister(rsp.getProvider());
        }
        Bukkit.getServicesManager().register(Economy.class, economyProvider, this, ServicePriority.Normal);
        vaultHooked = true;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        String playerId = event.getPlayer().getUniqueId().toString();
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
            double balance = loadPlayerBalance(playerId);
            playerBalances.put(playerId, balance);
        });
    }

    public double loadPlayerBalance(String playerId) {
        if (database == null) return getConfig().getDouble("start-balance", 0.0);
        
        try (PreparedStatement stmt = database.prepareStatement("SELECT balance FROM balances WHERE player_id = ?")) {
            stmt.setString(1, playerId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return rs.getDouble("balance");
            }
        } catch (SQLException e) {
            getLogger().log(Level.WARNING, "Failed to load balance for " + playerId, e);
        }
        return getConfig().getDouble("start-balance", 0.0);
    }

    // Public API
    public static ELITEEconomyHook getInstance() { return instance; }
    public EcoProvider getEconomyProvider() { return economyProvider; }
    public boolean isVaultHooked() { return vaultHooked; }
    public Double getCachedBalance(String playerId) { return playerBalances.get(playerId); }
    public void updateCachedBalance(String playerId, double balance) { playerBalances.put(playerId, balance); }
    public void removeCachedBalance(String playerId) { playerBalances.remove(playerId); }
    public Connection getDatabaseConnection() { return database; }
    
    public void savePlayerBalance(String playerId, double balance) {
        if (database == null) return;
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
            try (PreparedStatement stmt = database.prepareStatement("INSERT OR REPLACE INTO balances (player_id, balance) VALUES (?, ?)")) {
                stmt.setString(1, playerId);
                stmt.setDouble(2, balance);
                stmt.executeUpdate();
            } catch (SQLException e) {
                getLogger().log(Level.WARNING, "Failed to save balance for " + playerId, e);
            }
        });
    }
}
